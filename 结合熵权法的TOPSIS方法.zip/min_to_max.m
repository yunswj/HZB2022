function [y] = min_to_max(x)
          y = max(x) - x;
end